import React, { useState } from 'react';
import Counter from './components/Counter';
import ToggleMessage from './components/ToggleMessage';
import ParentComponent from './components/ParentComponent';
import GrandParent from './components/GrandParent';
import NameList from './components/List';
import CheckBoxMessage from './components/CheckBox'; 
import ControlledInput from './components/ControlledInputs';
import InputField from './components/InputField';
import Login from './components/login';
import ListItems from './components/ListItems';
import TodoApp from './components/TodoApp';
import CounterMethod from './components/CounterMethod';

function App() {
  const [value, setValue] = useState('');

  return (
    <div className="App">
      <Counter />
      <hr />

      <ToggleMessage />
      <hr />

      <ParentComponent />
      <hr />

      <GrandParent />
      <hr />

      <NameList />
      <hr />

      <CheckBoxMessage/>
      <hr />

      <ControlledInput />
      <hr />
      <InputField
        label="Username"
        name="username"
        placeholder="Enter your username"
        onChange={e => setValue(e.target.value)}
      />
      <p>Value: {value}</p>
      <hr />

      <Login />
      <hr />

      <ListItems />
      <hr />

      <TodoApp /> 
      <hr />

      <CounterMethod />
      <hr />
    </div>
  );
}

export default App;