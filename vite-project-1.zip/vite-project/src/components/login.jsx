import React, { useState } from 'react';

function Login() {
  const [user, setUser] = useState({ username: '', password: '' });

  return (
    <form>
      <h2>React 9 (loginform)</h2>
      <input
        name="username"
        placeholder=" Enter Your Username"
        value={user.username}
        onChange={e => setUser({ ...user, username: e.target.value })}
      />

      <input
        name="password"
        type="password"
        placeholder=" Enter Your Password"
        value={user.password}
        onChange={e => setUser({ ...user, password: e.target.value })}
      />
      <button type="submit" disabled={!user.username || !user.password}>
        Login
      </button>
    </form>
  );
}

export default Login;