

function NameList() {
  const names = ["John", "Jane", "Alex"];
  return (
    <div>
      <h2>React 5(using map)</h2>
      <h3>Names</h3>
      <ul>
        {names.map((name, id) => (
          <li key={id}>{name}</li>
        ))}
      </ul>
    </div>
  );
}

export default NameList;