import React, { useState } from 'react';

function CounterMethod() {
  const [count, setCount] = useState(0);

  const handleClick = () => {
    if (count === 9) {
      setCount(0);
    } else {
      setCount(count + 1);
    }
  };

  return (
    <div>
      <h2>React 12</h2>
      <h2>Count: {count}</h2>
      <button onClick={handleClick}>Add</button>
    </div>
  );
}

export default CounterMethod;