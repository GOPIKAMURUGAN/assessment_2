import React, { useState } from 'react';

function TodoApp() {
  const [todo, setTodo] = useState([]);
  const [input, setInput] = useState('');

  const addTodo = () => {
    setTodo([...todo, input]);
    setInput('');
  };

  const deleteTodo = (index) => {
    setTodo(todo.filter((_, i) => i !== index));
  };

  return (
    <div>
      <h2>React 11</h2>
      <h2>Todo App</h2>
      <input
        type="text"
        value={input}
        onChange={e => setInput(e.target.value)}
        placeholder="Add a todo"
      />
      <button onClick={addTodo}>Add</button>
      <ul>
        {todo.map((todo, idx) => (
          <li key={idx}>
            {todo}
            <button onClick={() => deleteTodo(idx)} style={{ marginLeft: '10px' }}>
              Delete
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default TodoApp;