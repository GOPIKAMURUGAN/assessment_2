import React, { useState } from 'react';

function ListItems() {
  const [items, setItems] = useState(['HTML', 'JAVA', 'PYTHON', 'REACT']);

  const handleDelete = (index) => {
    setItems(items.filter((_, i) => i !== index));
  };

  return (
    <div>
      <h2>React 10</h2>
      <h3>Item List</h3>
      <ul>
        {items.map((item, id) => (
          <li key={id}>
            {item}
            <button onClick={() => handleDelete(id)}  style={{ margin: '10px' }}>
              Delete
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default ListItems;