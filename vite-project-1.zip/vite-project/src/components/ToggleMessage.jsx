import React, { useState } from 'react';

function ToggleMessage() {
  const [showHello, setShowHello] = useState(true);

  const handleClick = () => {
    setShowHello(prev => !prev);
  };

  return (
    <div>
      <h2>React 2(toggle)</h2>
      <h2>{showHello ? "Hello" : "Welcome Back"}</h2>
      <button onClick={handleClick}>click it</button>
    </div>
  );
}

export default ToggleMessage;