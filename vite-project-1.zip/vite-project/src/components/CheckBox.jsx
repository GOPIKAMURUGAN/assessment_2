import React, { useState } from 'react';

function CheckBoxMessage() {
  const [checked, setChecked] = useState(false);

  return (
    <div>
      <h2>React 6(checkbox)</h2>
      <label>
        <input
          type="checkbox"
          checked={checked}
          onChange={e => setChecked(e.target.checked)}
        />
        Click me!
      </label>
      {checked && <p>You checked the box!</p>}
    </div>
  );
}

export default CheckBoxMessage;