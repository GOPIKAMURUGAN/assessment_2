// task1
import React, { useState } from 'react';

function Counter() {
  const [count, setCount] = useState(0);

  return (
    <div>
      <h2>React 1(count)</h2>
      <h2>Count: {count}</h2>
      <button onClick={() => setCount(count + 1)}>
        +
      </button>
    </div>
  );
}

export default Counter;