

function InputField(props) {
  return (
    <div>
      <h2> React 8 (InputField)</h2>
      <label>{props.label}</label>
      <input
        name={props.name}
        placeholder={props.placeholder}
        onChange={props.onChange}
      />
    </div>
  );
}

export default InputField;