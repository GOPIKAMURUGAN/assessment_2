import React, { useState } from 'react';

function ControlledInputs() {
  const [value, setValue] = useState('');

  const handleChange = (e) => {
    setValue(e.target.value);
  };

  return (
    <div>
      <h2> React 7 ControlledComponents</h2>
      <input 
        type="text"
        value={value}
        onChange={handleChange}
        placeholder="Enter your Name..."
        required
      />
      <p>Name: {value}</p>
    </div>
  );
}

export default ControlledInputs;