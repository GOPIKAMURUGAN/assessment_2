
import ChildComponent from './ChildComponent.jsx';

function ParentComponent() {
  return (
    <div>
      <h2>React 3 (props)</h2>
      <h2>ParentMessage</h2>
      <ChildComponent message="Good morning" />
    </div>
  );
}

export default ParentComponent;