import React from 'react';

function ChildComponent(props) {
  return (
    <div>
      <h3>ChildMessage</h3>
      <p>{props.message}</p>
    </div>
  );
}

export default ChildComponent;